var navlink=document.getElementById("nav-link");
function showmenu(){
  navlink.style.right="0";
}
function hidemenu(){
  navlink.style.right="-200px";
}